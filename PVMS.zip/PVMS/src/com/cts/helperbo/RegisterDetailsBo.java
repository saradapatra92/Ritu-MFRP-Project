package com.cts.helperbo;

import org.apache.log4j.Logger;

import com.cts.beans.Registration;
import com.cts.dao.RegisterDetailsDao;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;

public class RegisterDetailsBo {

	private  static Logger logger = Logger.getLogger(RegisterDetailsBo.class);
	public static boolean isUserExists(String user){
		logger.info("Starting isUserExists Method()...");
		RegisterDetailsDao objRegisterDao=new RegisterDetailsDao();
		boolean res=false;
		try {
			res=objRegisterDao.isUserExists(user);
			logger.info("isUserExists Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static String addCustomer(Registration objCustomer){
		logger.info("Starting addCustomer Method()...");
		RegisterDetailsDao objRegisterDao=new RegisterDetailsDao(); 
		String res="";
		try {
			res=objRegisterDao.addCustomer(objCustomer);
			logger.info("addCustomer Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static String validateLogin(String user)
	{
		logger.info("Starting validateLogin Method()...");
		RegisterDetailsDao objRegisterDao=new RegisterDetailsDao(); 
		String res="";
		try {
			res=objRegisterDao.validateLogin(user);
			logger.info("validateLogin Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static Registration searchByUserName(String userName){
		logger.info("Starting searchByUserName Method()...");
		RegisterDetailsDao objRegisterDao=new RegisterDetailsDao(); 
		Registration c=null;
		try {
			c=objRegisterDao.searchByUserName(userName);
			logger.info("searchByUserName Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return c;
	}
}
