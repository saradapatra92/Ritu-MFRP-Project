package com.cts.helperbo;

import org.apache.log4j.Logger;

import com.cts.beans.NewPassport;
import com.cts.beans.PassportRenewal;
import com.cts.dao.PassportDetailsDao;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;

public class PassportDetailsBo {

	private  static Logger logger = Logger.getLogger(PassportDetailsBo.class);
	
	public static NewPassport searchPassport(String passportNo){
		logger.info("Starting SearchPassport Method()...");
		PassportDetailsDao objPassportDao=new PassportDetailsDao();
		NewPassport res=null;
		try {
			res= objPassportDao.searchPassport(passportNo);
			logger.info("SearchPassport() Method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);

		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static String generatePassportNo() {
		logger.info("Starting generatePassportNo() Method...");
		PassportDetailsDao objPassportDao=new PassportDetailsDao();
		String res="";
		try {
			res=objPassportDao.generatePassportNo();
			logger.info("generatePassportNo() Method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static String generateExpiryDate(String passportNo){
		logger.info("Starting generateExpiryDate() Method...");
		PassportDetailsDao objPassportDao=new PassportDetailsDao();
		String res="";
		try {
			res=objPassportDao.generateExpiryDate(passportNo);
			logger.info("generateExpiryDate() Method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static String applyPassport(NewPassport objApplyPassport)
	{
		logger.info("Starting applyPassport() Method...");
		PassportDetailsDao objPassportDao=new PassportDetailsDao();
		String res="";
		try {
			res=objPassportDao.applyPassport(objApplyPassport);
			logger.info("applyPassport() Method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static boolean isUserExists(String user){
		logger.info("Starting isUserExists() Method...");
		PassportDetailsDao objPassportDao=new PassportDetailsDao();
		boolean res=false;
		try {
			res=objPassportDao.isUserExists(user);
			logger.info("isUserExists() Method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static NewPassport renewalPassportData(String userName) {
		logger.info("Starting renewalPassportData() Method...");
		PassportDetailsDao objPassportDao=new PassportDetailsDao();
		NewPassport p=null;
		try {
			p=objPassportDao.renewalPassportData(userName);
			logger.info("renewalPassportData() Method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return p;
	}

	public static String checkRenewPassPort(PassportRenewal objRenewPassport){
		logger.info("Starting checkRenewPassPort() Method...");
		PassportDetailsDao objPassportDao=new PassportDetailsDao();
		String res="";
		try {
			res=objPassportDao.checkRenewPassPort(objRenewPassport);
			logger.info("checkRenewPassPort() Method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static NewPassport renewPassportExpiry(String passportNo) {
		logger.info("Starting renewPassportExpiry() Method...");
		PassportDetailsDao objPassportDao=new PassportDetailsDao();
		NewPassport p=null;
		try {
			p=objPassportDao.renewPassportExpiry(passportNo);
			logger.info("renewPassportExpiry() Method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return p;
	}

	public static NewPassport searchByUserName(String userName){
		logger.info("Starting searchByUserName() Method...");
		PassportDetailsDao objPassportDao=new PassportDetailsDao();
		NewPassport p=null;
		try {
			p=objPassportDao.searchByUserName(userName);
			logger.info("searchByUserName() Method executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return p;
	}
}
