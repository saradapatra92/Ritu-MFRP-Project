package com.cts.helperbo;

import java.util.List;

import org.apache.log4j.Logger;

import com.cts.beans.NewVisa;
import com.cts.dao.VisaDetailsDao;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;

public class VisaDetailsBo {

	private  static Logger logger = Logger.getLogger(VisaDetailsBo.class);
	public static String visaExpire(String visaNo){
		logger.info("Starting visaExpire Method()...");
		VisaDetailsDao objVisaDao=new VisaDetailsDao(); 
		String res="";
		try {
			res=objVisaDao.visaExpire(visaNo);
			logger.info("visaExpire Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static NewVisa searchVisa(String visaNo){
		logger.info("Starting searchVisa Method()...");
		VisaDetailsDao objVisaDao=new VisaDetailsDao(); 
		NewVisa v=null;
		try {
			v=objVisaDao.searchVisa(visaNo);
			logger.info("searchVisa Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} 
		return v;
	}

	public static boolean isCheckVisaStatus(String visaNo) {
		logger.info("Starting isCheckVisaStatus Method()...");
		VisaDetailsDao objVisaDao=new VisaDetailsDao(); 
		boolean res=false;
		try {
			res=objVisaDao.isCheckVisaStatus(visaNo);
			logger.info("isCheckVisaStatus Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static NewVisa searchVisa(String visaNo,String visaType){
		logger.info("Starting searchVisa Method()...");
		VisaDetailsDao objVisaDao=new VisaDetailsDao();
		NewVisa p=null;
		try {
			p=objVisaDao.searchVisa(visaNo, visaType);
			logger.info("searchVisa Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return p;
	}

	public static String generateExpiryDate(String visaNo,String visaType){
		logger.info("Starting generateExpiryDate Method()...");
		VisaDetailsDao objVisaDao=new VisaDetailsDao();
		String res="";
		try {
			res=objVisaDao.generateExpiryDate(visaNo, visaType);
			logger.info("generateExpiryDate Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static String visaCancel(String visaNo) {
		logger.info("Starting visaCancel Method()...");
		VisaDetailsDao objVisaDao=new VisaDetailsDao();
		String res="";
		try {
			res=objVisaDao.visaCancel(visaNo);
			logger.info("visaCancel Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res=e.getMessage();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res=e.getMessage();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static String generateVisaNo() {
		logger.info("Starting generateVisaNo Method()...");
		VisaDetailsDao objVisaDao=new VisaDetailsDao();
		String res="";
		try {
			res=objVisaDao.generateVisaNo();
			logger.info("generateVisaNo Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static boolean isUserExists(String user,String passportNo){
		logger.info("Starting isUserExists Method()...");
		VisaDetailsDao objVisaDao=new VisaDetailsDao(); 
		boolean res=false;
		try {
			res=objVisaDao.isUserExists(user, passportNo);
			logger.info("isUserExists Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static String applyVisa(NewVisa objApplyVisa) {
		logger.info("Starting applyVisa Method()...");
		VisaDetailsDao objVisaDao=new VisaDetailsDao(); 
		String res="";
		try {
			res=objVisaDao.applyVisa(objApplyVisa);
			logger.info("applyVisa Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res=e.getMessage();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res=e.getMessage();
			logger.error("Error  " +e);
		}
		return res;
	}

	public static List<NewVisa> searchByUserName(String userName){
		logger.info("Starting searchByUserName Method()...");
		VisaDetailsDao objVisaDetailsDao=new VisaDetailsDao(); 
		List<NewVisa> v=null;
		try {
			v=objVisaDetailsDao.searchByUserName(userName);
			logger.info("searchByUserName Method() executed Successfully...");
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		} catch (DatabaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error("Error  " +e);
		}
		return v;
	}
}
