package com.cts.beans;

public class VisaCancellation {
	
	private String visaNo;
	private String visaType;
	private String visaForCountry;
	
	public String getVisaType() {
		return visaType;
	}
	public void setVisaType(String visaType) {
		this.visaType = visaType;
	}
	public String getVisaForCountry() {
		return visaForCountry;
	}
	public void setVisaForCountry(String visaForCountry) {
		this.visaForCountry = visaForCountry;
	}
	
	public String getVisaNo() {
		return visaNo;
	}
	public void setVisaNo(String visaNo) {
		this.visaNo = visaNo;
	}
}