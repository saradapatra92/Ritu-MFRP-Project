package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.beans.NewVisa;
import com.cts.helperbo.VisaDetailsBo;

/**
 * Servlet implementation class ApplyVisaServer
 */
public class NewVisaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(NewVisaServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NewVisaServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String b="";

		logger.debug("Inside ApplyVisa Servlet : Applying for Visa");
		NewVisa objApplyVisa =new NewVisa();

		objApplyVisa.setPassportNo(request.getParameter("passportNumber"));	       
		objApplyVisa.setUserName(request.getParameter("userName"));
		objApplyVisa.setAddress1(request.getParameter("address1"));
		objApplyVisa.setAddress2(request.getParameter("address2"));
		objApplyVisa.setCity(request.getParameter("city"));
		objApplyVisa.setState(request.getParameter("state"));
		objApplyVisa.setZipCode(request.getParameter("zipCode"));
		objApplyVisa.setCountry(request.getParameter("country"));
		objApplyVisa.setVisaForCountry(request.getParameter("visaForCountry"));		 
		objApplyVisa.setVisaType(request.getParameter("visaType"));
		objApplyVisa.setOccupation(request.getParameter("occupation"));

		PrintWriter out=response.getWriter();
		b=VisaDetailsBo.applyVisa(objApplyVisa);  

		HttpSession session=request.getSession(true);
		session.setAttribute("visaNo",objApplyVisa.getVisaNo()); 
		NewVisa dao=VisaDetailsBo.searchVisa(objApplyVisa.getVisaNo(),objApplyVisa.getVisaType());
		session.setAttribute("dao",dao);
		session.setAttribute("message",b);
		
		if(("Successfully Applied for visa...").equals(b)){  
			RequestDispatcher rd=request.getRequestDispatcher("ApplyVisaSuccess.jsp");  
			rd.include(request, response);  
			out.println("<script>document.getElementById('result2').style.visibility = 'visible';</script>");
		}  
		
		else{
			RequestDispatcher rd=request.getRequestDispatcher("ApplyVisaFail.jsp");  
			rd.include(request, response);
			out.println("<script>document.getElementById('result3').style.visibility = 'visible';</script>");
		}
	}
}
