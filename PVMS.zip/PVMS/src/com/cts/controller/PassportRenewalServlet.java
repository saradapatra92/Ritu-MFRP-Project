package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.beans.PassportRenewal;
import com.cts.helperbo.PassportDetailsBo;

/**
 * Servlet implementation class RenewPassportServlet
 */
public class PassportRenewalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(PassportRenewalServlet.class);
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PassportRenewalServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String passportNo="";
		String b="";

		logger.debug("Inside RenewPassport Servlet : RenewPassport Process...");
		PassportRenewal objRenewPassport =new PassportRenewal();
		passportNo=request.getParameter("passportNo");

		objRenewPassport.setPassportNo(passportNo);
		objRenewPassport.setReasonForRenewal(request.getParameter("reasonForRenewal"));
		objRenewPassport.setFirstName(request.getParameter("firstName"));
		objRenewPassport.setLastName(request.getParameter("lastName"));
		objRenewPassport.setUserName(request.getParameter("userName"));
		objRenewPassport.setAddress1(request.getParameter("address1"));	
		objRenewPassport.setAddress2(request.getParameter("address2"));
		objRenewPassport.setCity(request.getParameter("city"));
		objRenewPassport.setState(request.getParameter("state"));
		objRenewPassport.setZipCode(request.getParameter("zipCode"));
		objRenewPassport.setCountry(request.getParameter("country"));		       
		objRenewPassport.setTypeOfService(request.getParameter("typeOfService"));
		objRenewPassport.setBookletType(request.getParameter("bookletType"));

		//NewPassport objApplyPassport=new NewPassport();
		PrintWriter out=response.getWriter();

		b=PassportDetailsBo.checkRenewPassPort(objRenewPassport);
		HttpSession session=request.getSession(true);

		if(("Record Inserted...").equals(b)){
			session.setAttribute("dao",objRenewPassport);
			RequestDispatcher rd=request.getRequestDispatcher("RenewPassportSuccess.jsp");  
			rd.include(request, response);  
			out.println("<script>document.getElementById('result3').style.visibility = 'visible';</script>");
		}

		else{
			RequestDispatcher rd=request.getRequestDispatcher("RenewPassportFail.jsp");  
			rd.include(request, response);  
			out.println("<script>document.getElementById('result3').style.visibility = 'visible';</script>");
		}
	}
}