package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.helperbo.VisaDetailsBo;

/**
 * Servlet implementation class VisaCancelServer
 */
public class VisaCancellationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(VisaCancellationServlet.class);
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public VisaCancellationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String visaNo="";
		String msg="";

		logger.debug("Inside VisaCancel Servlet : VisaCancel Process...");
		PrintWriter out=response.getWriter();
		visaNo=request.getParameter("visaNo");
		msg=VisaDetailsBo.visaCancel(visaNo);
		HttpSession session=request.getSession(true);
		session.setAttribute("visaCancelMsg", msg);

		if(("Visa Successfully Cancelled").equals(msg)){
			RequestDispatcher rd=request.getRequestDispatcher("VisaCancel.jsp");  
			rd.include(request, response);  
			out.println("<script>document.getElementById('VisaCancelSuccess').style.visibility = 'visible';</script>");
		}
		else{
			RequestDispatcher rd=request.getRequestDispatcher("VisaCancel.jsp");  
			rd.include(request, response);  
			out.println("<script>document.getElementById('VisaCancelFail').style.visibility = 'visible';</script>");
		}
	}
}