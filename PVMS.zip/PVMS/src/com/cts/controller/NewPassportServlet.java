package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cts.beans.NewPassport;
import com.cts.helperbo.PassportDetailsBo;


/**
 * Servlet implementation class ApplyPassportServer
 */
public class NewPassportServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private static Logger logger = Logger.getLogger(NewPassportServlet.class);
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NewPassportServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String b="";

		logger.debug("Inside ApplyPassport Servlet : Applying for passport");
		PrintWriter out=response.getWriter();
		//HttpSession session1=request.getSession(false);

		NewPassport objApplyPassport =new NewPassport();	
		objApplyPassport.setUserName(request.getParameter("userName"));
		objApplyPassport.setAddress1(request.getParameter("address1"));	
		objApplyPassport.setAddress2(request.getParameter("address2"));
		objApplyPassport.setCity(request.getParameter("city"));
		objApplyPassport.setState(request.getParameter("state"));
		objApplyPassport.setZipCode(request.getParameter("zipCode"));
		objApplyPassport.setCountry(request.getParameter("country"));		       
		objApplyPassport.setPassportOffice(request.getParameter("passportoffice"));		      
		objApplyPassport.setTypeOfService(request.getParameter("typeOfService"));
		objApplyPassport.setBookletType(request.getParameter("bookletType"));

		b=PassportDetailsBo.applyPassport(objApplyPassport);

		HttpSession session=request.getSession(true);
		session.setAttribute("passportNo",objApplyPassport.getPassportNo()); 
		NewPassport dao=PassportDetailsBo.searchPassport(objApplyPassport.getPassportNo());
		session.setAttribute("dao",dao);
		session.setAttribute("message",b);

		if(("Successfully Applied...").equals(b)){  	
			HttpSession s=request.getSession(true);
			s.setAttribute("app","success");	
			RequestDispatcher rd=request.getRequestDispatcher("ApplyPassportSuccess.jsp");  
			rd.include(request, response);  
			out.println("<script>document.getElementById('result2').style.visibility = 'visible';</script>");
		}  

		else{  						
			RequestDispatcher disp=request.getRequestDispatcher("ApplyPassport.jsp");
			disp.include(request, response);					
			out.println("<script>document.getElementById('result3').style.visibility = 'visible';</script>");
		}
	}
}
