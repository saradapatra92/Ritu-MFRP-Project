package com.cts.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cts.beans.NewVisa;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.utilities.DBUtility;
import com.cts.utilities.PropertyUtil;


public class VisaDetailsDao {

	private  static Logger logger = Logger.getLogger(VisaDetailsDao.class);

	public String visaCancel(String visaNo) throws ValidationException,DatabaseException {
		String cmd="";
		String res="";
		cmd="update applyVisa set visaStatus='Inactive' where VisaNo=?";
		Connection con=DBUtility.getConnection();

		try {
			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setString(1,visaNo);
			pst.executeUpdate();
			res="Visa Cancelled Successfully...";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res=e.getMessage();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return res;
	}

	public String visaExpire(String visaNo) throws ValidationException,DatabaseException{
		boolean flag=isCheckVisaStatus(visaNo);  
		String msg="";
		String cmd="";
		if(flag==false)
		{
			msg="Visa Successfully Cancelled";
		}
		else
		{
			NewVisa objVisa=searchVisa(visaNo);
			Connection con=DBUtility.getConnection();

			if(objVisa!=null){
				Date dt=objVisa.getExpiryDate();
				cmd="select datediff(curDate(),?) dif";
				try {
					PreparedStatement pst=con.prepareStatement(cmd);
					pst.setDate(1,dt);
					ResultSet rs=pst.executeQuery();
					rs.next();
					int dif=rs.getInt("dif");					
					if(dif > 0){
						msg="Already Expired";
					}
					else {
						cmd="update ApplyVisa set visaStatus='Inactive' where VisaNo=?";
						pst=con.prepareStatement(cmd);
						pst.setString(1, visaNo);
						pst.executeUpdate();
						msg="Visa Successfully Cancelled";
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					logger.error(PropertyUtil.getMessage(e.getMessage()));
				} finally {
					try {
						con.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} 
			}
			else {
				msg="Invalid VisaNo...";
			}
		}
		return msg;
	}

	public NewVisa searchVisa(String visaNo) throws ValidationException,DatabaseException{
		String cmd="";
		Connection con=DBUtility.getConnection();
		NewVisa objVisa=null;
		cmd="select * from ApplyVisa where Visano=?";

		try {
			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setString(1,visaNo);
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				objVisa=new NewVisa();
				objVisa.setVisaNo(rs.getString("visano"));
				objVisa.setPassportNo(rs.getString("passportNo"));
				objVisa.setUserName(rs.getString("userName"));
				objVisa.setAddress1(rs.getString("address1"));
				objVisa.setAddress2(rs.getString("address2"));
				objVisa.setCity(rs.getString("city"));
				objVisa.setState(rs.getString("state"));
				objVisa.setZipCode(rs.getString("zipCode"));
				objVisa.setCountry(rs.getString("country"));
				objVisa.setVisaForCountry(rs.getString("visaForCountry"));
				objVisa.setVisaType(rs.getString("visaType"));
				objVisa.setOccupation(rs.getString("occupation"));
				objVisa.setIssueDate(rs.getDate("issueDate"));
				objVisa.setExpiryDate(rs.getDate("expiryDate"));
				objVisa.setStatus(rs.getString("status"));
			}
			else {
				objVisa=null;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return objVisa;
	}

	public boolean isCheckVisaStatus(String visaNo) throws ValidationException,DatabaseException {
		String cmd="";
		String status="";
		boolean flag=false;
		Connection con=DBUtility.getConnection();
		cmd="select visaStatus from ApplyVisa where Visano=?";

		try {
			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setString(1,visaNo);
			ResultSet rs=pst.executeQuery();

			if(rs.next()){
				status=rs.getString(1);
			}

			if(status.equals("Inactive"))
			{
				flag=false;
			}

			else
			{
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return flag;
	}

	public NewVisa searchVisa(String visaNo,String visaType) throws ValidationException,DatabaseException{
		String cmd="";
		Connection con=DBUtility.getConnection();
		NewVisa visa=null;
		cmd="select * from applyVisa where visaNo=?";
		generateExpiryDate(visaNo,visaType);

		try {
			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setString(1,visaNo);
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				visa=new NewVisa();
				visa.setPassportNo(rs.getString("passportNo"));
				visa.setUserName(rs.getString("userName"));
				visa.setAddress1(rs.getString("address1"));
				visa.setAddress2(rs.getString("address2"));
				visa.setCity(rs.getString("city"));
				visa.setState(rs.getString("state"));
				visa.setZipCode(rs.getString("zipCode"));
				visa.setCountry(rs.getString("country"));
				visa.setVisaForCountry(rs.getString("visaForCountry"));				
				visa.setVisaType(rs.getString("visaType"));
				visa.setOccupation(rs.getString("occupation"));
				visa.setVisaNo(rs.getString("visaNo")); 
				visa.setIssueDate(rs.getDate("issueDate"));
				visa.setExpiryDate(rs.getDate("expiryDate"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return visa;
	}


	public String generateExpiryDate(String visaNo,String visaType) throws ValidationException,DatabaseException{
		String cmd="";
		String res="";

		if(visaType.equals("Tourist"))
		{
			cmd="select DATE_ADD(curdate(), INTERVAL 6 MONTH) exp";
		}
		if(visaType.equals("Student"))
		{
			cmd="select DATE_ADD(curdate(), INTERVAL 2 YEAR) exp";
		}	
		if(visaType.equals("Business"))
		{
			cmd="select DATE_ADD(curdate(), INTERVAL 1 YEAR) exp";
		}
		if(visaType.equals("Transit"))
		{
			cmd="select DATE_ADD(curdate(), INTERVAL 5 DAY) exp";
		}

		Connection con=DBUtility.getConnection();		
		PreparedStatement pst;

		try {
			pst = con.prepareStatement(cmd);
			ResultSet rs=pst.executeQuery();
			rs.next(); 
			cmd="update ApplyVisa set expiryDate=? where visaNo=?";
			pst=con.prepareStatement(cmd); 
			pst.setDate(1,rs.getDate("exp")); 
			pst.setString(2,visaNo); 
			pst.executeUpdate();
			res="Expiry Date Created Successfully...";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res=e.getMessage();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return res;
	}

	public String generateVisaNo()  throws ValidationException,DatabaseException  {
		String visaNo="";
		String cmdApplyPassport="";
		String pno="";
		int no;
		Connection con=DBUtility.getConnection();
		cmdApplyPassport="select count(*) cnt from applyVisa";		
		PreparedStatement pst;
		ResultSet rs;

		try {
			pst=con.prepareStatement(cmdApplyPassport);
			rs=pst.executeQuery();
			rs.next();
			int cnt=rs.getInt("cnt");

			if(cnt==0){
				visaNo="VI2018I001";
			}
			else {
				cmdApplyPassport="select visaNo from applyvisa";
				pst=con.prepareStatement(cmdApplyPassport); 
				rs=pst.executeQuery();				

				while(rs.next()){
					pno=rs.getString("visaNo");
				}

				String part=pno.substring(7);				
				no=Integer.parseInt(part);
				no++;
				if(no >= 1 && no <= 9){
					visaNo="VI2018I00"+no; 
				}
				if(no >= 10 && no <= 99){
					visaNo="VI2018I0"+no;
				}
				if(no >= 100 && no <= 999){
					visaNo="VI2018I"+no;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return visaNo ;
	}

	public boolean isUserExists(String user,String passportNo) throws ValidationException,DatabaseException {
		boolean flag=false;
		String userCmd="";
		userCmd="select userName from applyPassport where userName=? and passportNo=?";
		Connection con=DBUtility.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(userCmd);
			pst.setString(1,user); 
			pst.setString(2,passportNo);

			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return flag;
	}

	public boolean isCheckVisaForCountry(NewVisa objApplyVisa)
	{
		String userCmd="";
		boolean flag= false;
		Connection con=DBUtility.getConnection();
		userCmd="Select count(*) from applyVisa where username=? and visaForCountry=? and visaStatus='active'";
		PreparedStatement pst;
		int n=0;

		try {
			pst = con.prepareStatement(userCmd);
			pst.setString(1,objApplyVisa.getUserName());
			pst.setString(2,objApplyVisa.getVisaForCountry());
			ResultSet rs=pst.executeQuery();  
			if(rs.next()){
				n=rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		if(n>0)
		{
			flag=true;
		}
		else
		{
			flag=false;

		}
		return flag;
	}

	public String applyVisa(NewVisa objApplyVisa) throws ValidationException, DatabaseException {
		String userCmd="";
		String msg="";
		boolean flag=isUserExists(objApplyVisa.getUserName(),objApplyVisa.getPassportNo());
		boolean flag2=isCheckVisaForCountry(objApplyVisa);
		userCmd="Insert into applyVisa(passportNo,userName,address1,address2,city,"
				+ "state,zipCode,country,visaForCountry,visaType,occupation,visaNo) values(?,?,?,?,?,?,?,?,?,?,?,?)";

		if(flag == true && flag2 == false)
		{
			objApplyVisa.setVisaNo(generateVisaNo());
			Connection con=DBUtility.getConnection();
			try {
				PreparedStatement pst=con.prepareStatement(userCmd);
				pst.setString(1,objApplyVisa.getPassportNo());
				pst.setString(2,objApplyVisa.getUserName());
				pst.setString(3, objApplyVisa.getAddress1());
				pst.setString(4, objApplyVisa.getAddress2());
				pst.setString(5, objApplyVisa.getCity());
				pst.setString(6, objApplyVisa.getState());
				pst.setString(7, objApplyVisa.getZipCode());
				pst.setString(8, objApplyVisa.getCountry());				
				pst.setString(9,objApplyVisa.getVisaForCountry());
				pst.setString(10,objApplyVisa.getVisaType());
				pst.setString(11,objApplyVisa.getOccupation());
				pst.setString(12,objApplyVisa.getVisaNo());				

				int n=pst.executeUpdate();
				if(n>0){
					msg="Successfully Applied for visa...";						
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}	finally {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 	
		}
		else
		{
			if(flag2== true)
			{
				msg="User already applied for Country"+objApplyVisa.getVisaForCountry();
			}
			else
			{
				msg="User does not exists";
			}
		}

		return msg;
	}

	public boolean isUserAlreadyApplied(String user) throws ValidationException,DatabaseException{
		boolean flag=false;
		String userCmd="";
		userCmd="select userName from applyVisa where userName=?";
		Connection con=DBUtility.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(userCmd);
			pst.setString(1,user); 
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return flag;
	}

	public List<NewVisa> searchByUserName(String userName) throws ValidationException,DatabaseException {
		String cmd="";
		int cnt=0;
		int i=0;
		Connection con=DBUtility.getConnection();
		cmd="Select count(*) cnt from ApplyVisa where username=? AND visastatus='Active'";
		PreparedStatement pst=null;
		ResultSet rs=null;

		List<NewVisa> arrVisa=new ArrayList<NewVisa>();
		try {
			pst=con.prepareStatement(cmd);
			pst.setString(1,userName); 
			rs=pst.executeQuery();
			rs.next();
			cnt=rs.getInt("cnt"); 

			if(cnt > 0){

				cmd="select * from ApplyVisa where userName=? AND visastatus='Active'";
				pst=con.prepareStatement(cmd);
				pst.setString(1,userName); 
				NewVisa objVisa=null; 
				rs=pst.executeQuery(); 

				while(rs.next()){
					objVisa=new NewVisa(); 
					objVisa.setPassportNo(rs.getString("passportNo"));
					objVisa.setAddress1(rs.getString("Address1")); 
					objVisa.setAddress2(rs.getString("Address2"));
					objVisa.setCity(rs.getString("city"));
					objVisa.setCountry(rs.getString("country"));
					objVisa.setExpiryDate(rs.getDate("expirydate"));
					objVisa.setIssueDate(rs.getDate("issueDate"));
					objVisa.setOccupation(rs.getString("occupation"));
					objVisa.setState(rs.getString("state"));				
					objVisa.setUserName(rs.getString("userName"));
					objVisa.setVisaForCountry(rs.getString("VisaForCountry"));
					objVisa.setVisaNo(rs.getString("VisaNo"));
					objVisa.setVisaType(rs.getString("VisaType"));
					arrVisa.add(objVisa);
					i++;
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return arrVisa;
	}
}
