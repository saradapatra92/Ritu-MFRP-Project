package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cts.beans.Registration;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.utilities.DBUtility;
import com.cts.utilities.PropertyUtil;

public class RegisterDetailsDao {

	private  static Logger logger = Logger.getLogger(RegisterDetailsDao.class);
	public boolean isUserExists(String user) throws ValidationException,DatabaseException{
		String userCmd="";
		boolean flag=false;
		userCmd="select userName from Customer where userName=?";
		Connection con=DBUtility.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(userCmd);
			pst.setString(1,user); 
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return flag;
	}

	public String addCustomer(Registration objCustomer) throws ValidationException, DatabaseException{
		String msg="";		
		boolean flag=isUserExists(objCustomer.getUserName());

		if(flag==false){
			Connection con=DBUtility.getConnection();
			String cmdCustIns="Insert into Customer(firstName,lastName,userName,password,gender,"
					+ "dateofbirth,mobile,email,qualification,address1,address2,city,state,zipCode,"
					+ "country,hintquestion,hintanswer) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			try {
				PreparedStatement pst=con.prepareStatement(cmdCustIns);
				pst.setString(1,objCustomer.getFirstName());
				pst.setString(2,objCustomer.getLastName());
				pst.setString(3,objCustomer.getUserName());
				pst.setString(4,objCustomer.getPassWord());
				pst.setString(5,objCustomer.getGender());
				pst.setDate(6,objCustomer.getDateOfBirth());
				pst.setString(7,objCustomer.getMobile());
				pst.setString(8,objCustomer.getEmail());
				pst.setString(9,objCustomer.getQualification());
				pst.setString(10,objCustomer.getAddress1());
				pst.setString(11,objCustomer.getAddress2());
				pst.setString(12,objCustomer.getCity());
				pst.setString(13,objCustomer.getState());
				pst.setString(14,objCustomer.getZipCode());
				pst.setString(15,objCustomer.getCountry());			
				pst.setString(16,objCustomer.getHintQuestion());
				pst.setString(17,objCustomer.getHintAnswer());
				int n=pst.executeUpdate();
				if(n>0){
					msg="Record Inserted...";
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}finally {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
		}
		else {
			msg="UserID Already Exists...";
		}
		return msg;
	}

	public Registration searchByUserName(String userName) throws ValidationException,DatabaseException{
		String cmd="";
		Connection con=DBUtility.getConnection();
		Registration objCustomer=null;
		cmd="Select * from Customer where username=?";
		try {

			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setString(1,userName);
			ResultSet rs=pst.executeQuery();  
			if(rs.next()){
				objCustomer=new Registration(); 
				objCustomer.setFirstName(rs.getString("firstName"));
				objCustomer.setLastName(rs.getString("lastName"));
				objCustomer.setDateOfBirth(rs.getDate("dateOfBirth"));
				objCustomer.setMobile(rs.getString("mobile"));
				objCustomer.setEmail(rs.getString("email"));
				objCustomer.setQualification(rs.getString("qualification"));
				objCustomer.setAddress1(rs.getString("address1"));
				objCustomer.setAddress2(rs.getString("address2"));
				objCustomer.setCity(rs.getString("city"));			
				objCustomer.setState(rs.getString("state"));
				objCustomer.setZipCode(rs.getString("zipCode"));			
				objCustomer.setCountry(rs.getString("country"));

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return objCustomer;
	}

	public String validateLogin(String user) throws ValidationException, DatabaseException
	{
		boolean flag=isUserExists(user);
		String msg="";
		String cmdCustLogin="";
		if(flag==true){

			Connection con=DBUtility.getConnection();
			cmdCustLogin="Select password from Customer where username=?";					

			try {
				PreparedStatement pst=con.prepareStatement(cmdCustLogin);
				pst.setString(1,user);
				ResultSet rs=pst.executeQuery();  
				while(rs.next()){  
					msg=rs.getString(1);
				}  
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}finally {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
		}
		else
		{
			msg="Username does not exists....";
		}
		return msg;
	}
}
