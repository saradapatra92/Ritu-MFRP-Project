package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cts.beans.NewPassport;
import com.cts.beans.PassportRenewal;
import com.cts.exceptions.DatabaseException;
import com.cts.exceptions.ValidationException;
import com.cts.utilities.DBUtility;
import com.cts.utilities.PropertyUtil;

public class PassportDetailsDao {

	private  static Logger logger = Logger.getLogger(PassportDetailsDao.class);
	public NewPassport searchPassport(String passportNo) throws ValidationException,DatabaseException{
		String cmd="";
		Connection con=DBUtility.getConnection();
		NewPassport passport=null;
		cmd="select * from ApplyPassport where passportNo=?";
		generateExpiryDate(passportNo);
		try {

			PreparedStatement pst=con.prepareStatement(cmd);
			pst.setString(1,passportNo);
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				passport=new NewPassport();
				passport.setPassportNo(rs.getString("passportNo"));
				passport.setUserName(rs.getString("userName"));		
				passport.setAddress1(rs.getString("address1"));
				passport.setAddress2(rs.getString("address2"));
				passport.setCity(rs.getString("city"));
				passport.setState(rs.getString("state"));
				passport.setZipCode(rs.getString("zipCode"));
				passport.setCountry(rs.getString("country"));
				passport.setPassportOffice(rs.getString("passportOffice")); 
				passport.setBookletType(rs.getString("bookletType"));
				passport.setTypeOfService(rs.getString("typeOfService"));				
				passport.setIssueDate(rs.getDate("issueDate"));
				passport.setExpiryDate(rs.getDate("expiryDate"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return passport;
	}

	public String generatePassportNo() throws ValidationException,DatabaseException {
		String passportNo="";
		String pno="";
		String part="";
		int no;
		Connection con=DBUtility.getConnection();
		String cmdApplyPassport="select count(*) cnt from applypassport";		
		PreparedStatement pst;
		ResultSet rs;
		try {
			pst=con.prepareStatement(cmdApplyPassport);
			rs=pst.executeQuery();
			rs.next();
			int cnt=rs.getInt("cnt");
			if(cnt==0){
				passportNo="PS2018I001";
			}
			else {
				cmdApplyPassport="select passportNo from applypassport";
				pst=con.prepareStatement(cmdApplyPassport); 
				rs=pst.executeQuery();

				while(rs.next()){
					pno=rs.getString("passportNo");
				}				
				part=pno.substring(7);
				no=Integer.parseInt(part);
				no++;
				if(no >= 1 && no <= 9){
					passportNo="PS2018I00"+no; 
				}
				if(no >= 10 && no <= 99){
					passportNo="PS2018I0"+no;
				}
				if(no >= 100 && no <= 999){
					passportNo="PS2018I"+no;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}	
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return passportNo;
	}

	public String generateExpiryDate(String passportNo) throws ValidationException,DatabaseException{
		String res="";
		String cmd="";
		cmd="select DATE_ADD(curdate(), INTERVAL 5 YEAR) exp";
		Connection con=DBUtility.getConnection();

		PreparedStatement pst;
		try {
			pst = con.prepareStatement(cmd);
			ResultSet rs=pst.executeQuery();
			rs.next(); 
			cmd="update ApplyPassport set expiryDate=? where passportNo=?";
			pst=con.prepareStatement(cmd); 
			pst.setDate(1,rs.getDate("exp")); 
			pst.setString(2,passportNo); 
			pst.executeUpdate();
			res="Expiry Date Created Successfully...";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			res=e.getMessage();
		} 
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return res;

	}
	public String applyPassport(NewPassport objApplyPassport) throws ValidationException, DatabaseException
	{
		String msg="";
		int n;
		RegisterDetailsDao cd=new RegisterDetailsDao();
		boolean flag=cd.isUserExists(objApplyPassport.getUserName());
		boolean flag2=isUserExists(objApplyPassport.getUserName());

		if(flag==true  && flag2==false){
			Connection con=DBUtility.getConnection();
			objApplyPassport.setPassportNo(generatePassportNo());
			String cmdApplyPassIns="Insert into applyPassport(userName,address1,address2,city,state,zipCode,"
					+ "country,passportOffice,typeOfService,bookletType,passportNo) values(?,?,?,?,?,?,?,?,?,?,?)";
			try {
				PreparedStatement pst=con.prepareStatement(cmdApplyPassIns);
				pst.setString(1, objApplyPassport.getUserName());		
				pst.setString(2, objApplyPassport.getAddress1());
				pst.setString(3, objApplyPassport.getAddress2());
				pst.setString(4, objApplyPassport.getCity());
				pst.setString(5, objApplyPassport.getState());
				pst.setString(6, objApplyPassport.getZipCode());
				pst.setString(7, objApplyPassport.getCountry());
				pst.setString(8, objApplyPassport.getPassportOffice());
				pst.setString(9, objApplyPassport.getTypeOfService());
				pst.setString(10,objApplyPassport.getBookletType());
				pst.setString(11,objApplyPassport.getPassportNo());
				n=pst.executeUpdate();

				if(n>0){
					msg="Successfully Applied...";
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}
			finally {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 

		}
		else {
			if(flag == false)
			{
				msg="Invalid UserName";
			}
			else if(flag2==true)
			{
				msg="User already applied for passport";
			}
		} 

		return msg;
	}


	public boolean isUserExists(String user) throws ValidationException,DatabaseException{
		boolean flag=false;
		String userCmd="";
		userCmd="select userName from applyPassport where userName=?";
		Connection con=DBUtility.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(userCmd);
			pst.setString(1,user); 
			ResultSet rs=pst.executeQuery();
			if(rs.next()){
				flag=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return flag;
	}

	public NewPassport renewalPassportData(String userName) throws ValidationException,DatabaseException {
		String userCmd="";
		NewPassport objApplyPassport=new NewPassport();
		userCmd="select passportNo,issueDate,expiryDate from applyPassport where userName=?";
		Connection con=DBUtility.getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(userCmd);
			pst.setString(1,userName); 
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				objApplyPassport.setPassportNo(rs.getString(1));
				objApplyPassport.setIssueDate(rs.getDate(2));
				objApplyPassport.setExpiryDate(rs.getDate(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return objApplyPassport;
	}


	public String checkRenewPassPort(PassportRenewal objRenewPassport) throws ValidationException, DatabaseException{
		String msg="";
		String objApplyPassport2="";
		int n;
		Connection con=DBUtility.getConnection();
		PassportDetailsDao dao=new PassportDetailsDao(); 
		NewPassport obj=dao.searchPassport(objRenewPassport.getPassportNo());

		if(objRenewPassport.getReasonForRenewal().equals("passportExpired"))
		{
			objApplyPassport2=renewPassportExpiry_nw(obj.getPassportNo());
			if(objApplyPassport2.equals("empty"))
			{
				msg="Passport Not Yet expired";
			}
			else
			{
				objRenewPassport.setIssueDate(obj.getIssueDate());
				objRenewPassport.setExpiryDate(obj.getExpiryDate());
			}
		}
		else
		{
			objRenewPassport.setIssueDate(obj.getIssueDate());
			objRenewPassport.setExpiryDate(obj.getExpiryDate());
		}

		try {			
			String cmd="Insert into renewPassport(userName,reasonForRenewal,firstName,lastName,Address1,Address2,"
					+ "City,State,ZipCode,Country,typeOfService,bookletType,passportNo,issueDate,expiryDate)"
					+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			PreparedStatement pst=con.prepareStatement(cmd);			

			pst.setString(1,objRenewPassport.getUserName());
			pst.setString(2,objRenewPassport.getReasonForRenewal());
			pst.setString(3,objRenewPassport.getFirstName());
			pst.setString(4,objRenewPassport.getLastName());
			pst.setString(5,objRenewPassport.getAddress1());
			pst.setString(6,objRenewPassport.getAddress2());
			pst.setString(7,objRenewPassport.getCity());
			pst.setString(8,objRenewPassport.getState());
			pst.setString(9,objRenewPassport.getZipCode());
			pst.setString(10,objRenewPassport.getCountry());
			pst.setString(11,objRenewPassport.getTypeOfService());
			pst.setString(12,objRenewPassport.getBookletType());
			pst.setString(13,objRenewPassport.getPassportNo());
			pst.setDate(14,objRenewPassport.getIssueDate());
			pst.setDate(15,objRenewPassport.getExpiryDate());

			n=pst.executeUpdate();
			if(n>0){
				msg="Record Inserted...";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}	
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 	
		return msg;
	}


	public String renewPassportExpiry_nw(String passportNo) throws ValidationException, DatabaseException {

		String msgobj="";
		int dif;
		Connection con=DBUtility.getConnection();
		PassportDetailsDao dao=new PassportDetailsDao(); 
		NewPassport obj=dao.searchPassport(passportNo);		

		if(obj!=null){
			try {
				PreparedStatement pst=con.prepareStatement("select datediff(curDate(),?) dif");
				pst.setDate(1,obj.getExpiryDate());
				ResultSet rs=pst.executeQuery();
				rs.next();
				dif=rs.getInt("dif");
				System.out.println(dif);

				if(dif < 0){
					msgobj ="empty";
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}			
			
			finally {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
		}

		return msgobj;	
	}

	public NewPassport renewPassportExpiry(String passportNo) throws ValidationException, DatabaseException {
		String cmd="";
		Connection con=DBUtility.getConnection();
		PassportDetailsDao dao=new PassportDetailsDao(); 
		NewPassport obj=dao.searchPassport(passportNo);


		if(obj!=null){
			try {
				PreparedStatement pst=con.prepareStatement("select datediff(curDate(),?) dif");
				pst.setDate(1,obj.getExpiryDate());
				ResultSet rs=pst.executeQuery();
				rs.next();
				int dif=rs.getInt("dif");

				if(dif < 0){
					obj =null;
				}

				else {
					dao.generateExpiryDate(passportNo);
					cmd="Insert into renewPassport(passportNo,RenewalReason) values(?,?)";
					pst=con.prepareStatement(cmd); 
					pst.setString(1,passportNo);
					pst.setString(2,"Passport Expired");
					pst.executeUpdate();

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error(PropertyUtil.getMessage(e.getMessage()));
			}			
			finally {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} 
		}
		return obj;	
	}

	public NewPassport searchByUserName(String userName) throws ValidationException,DatabaseException {
		String cmd="";
		Connection con=DBUtility.getConnection();
		NewPassport objApplyPassport=null;
		cmd="Select * from applyPassport where username=?";
		PreparedStatement pst;
		try {
			pst = con.prepareStatement(cmd);
			pst.setString(1,userName);
			ResultSet rs=pst.executeQuery(); 
			if(rs.next()){
				objApplyPassport=new NewPassport();
				objApplyPassport.setUserName(rs.getString("userName"));
				objApplyPassport.setAddress1(rs.getString("address1"));
				objApplyPassport.setAddress2(rs.getString("address2"));
				objApplyPassport.setCity(rs.getString("city"));
				objApplyPassport.setState(rs.getString("state"));
				objApplyPassport.setZipCode(rs.getString("zipCode"));
				objApplyPassport.setCountry(rs.getString("country"));
				objApplyPassport.setIssueDate(rs.getDate("issueDate"));
				objApplyPassport.setExpiryDate(rs.getDate("expiryDate"));
				objApplyPassport.setPassportNo(rs.getString("passportNo"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 

		return objApplyPassport;
	}	


	public PassportRenewal searchByUserName1(String userName) throws ValidationException,DatabaseException {
		String cmd="";
		Connection con=DBUtility.getConnection();
		PassportRenewal objRenewPassport=null;
		cmd="Select * from renewPassport where username=?";
		PreparedStatement pst;
		try {
			pst = con.prepareStatement(cmd);
			pst.setString(1,userName);
			ResultSet rs=pst.executeQuery(); 
			if(rs.next()){
				objRenewPassport=new PassportRenewal();
				objRenewPassport.setUserName(rs.getString("userName"));
				objRenewPassport.setPassportNo(rs.getString("passportNo"));
				objRenewPassport.setReasonForRenewal(rs.getString("reasonForRenewal"));
				objRenewPassport.setFirstName(rs.getString("firstName"));
				objRenewPassport.setLastName(rs.getString("lastName"));
				objRenewPassport.setAddress1(rs.getString("address1"));
				objRenewPassport.setAddress2(rs.getString("address2"));
				objRenewPassport.setCity(rs.getString("city"));
				objRenewPassport.setState(rs.getString("state"));
				objRenewPassport.setZipCode(rs.getString("zipCode"));
				objRenewPassport.setCountry(rs.getString("country"));
				objRenewPassport.setTypeOfService(rs.getString("typeOfService"));
				objRenewPassport.setBookletType(rs.getString("bookletType"));
				objRenewPassport.setExpiryDate(rs.getDate("expiryDate"));
				objRenewPassport.setIssueDate(rs.getDate("issueDate"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(PropertyUtil.getMessage(e.getMessage()));
		}		
		
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		return objRenewPassport;			
	}
}
