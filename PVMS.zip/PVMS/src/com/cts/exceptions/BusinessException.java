package com.cts.exceptions;

import java.sql.SQLException;

public class BusinessException extends SQLException{
	String message=null;
//	String message="ERROR:Passport User registration Exception";
	public BusinessException(String message){
		this.message=message;		
	}
	
	public String getMessage()
	{
		return message;
	}
}
