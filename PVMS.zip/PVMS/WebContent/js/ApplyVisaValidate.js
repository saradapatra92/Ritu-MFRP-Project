function doValidate() {
	var error="";
			
	var zip=frmApplyVisa.zipCode.value;	
	var patt2 =/^\d{6}$/;	
	
	if(!zip.match(patt2)){		
		error+="Enter Valid Zip Code Number\n";
		document.getElementById("errZip").innerHTML="Enter 6 digit ZipCode";
	}		
	
	if(error!=""){		
		return false;
	}
}