function doValidate() {

	var error="";			
	
	var firstn=frmRenewPassport.firstName.value;
	if(!firstn.match(/^[A-Za-z]+$/)){
		error+="Enter Valid First Name <br/>";
		document.getElementById("errfirstName").innerHTML="Please use alphabets";
	}

	var lastn=frmRenewPassport.lastName.value;

	if(lastn!=null){
		if(!lastn.match(/^[A-Za-z]+$/)){
			error+="Enter Valid Last Name <br/>";
			document.getElementById("errlastName").innerHTML="Please use alphabets";
		}
	}

	var zip=frmRenewPassport.zipCode.value;
	var patt3 =/^\d{6}$/;
	
	if(!zip.match(patt3)){
		
		error+="Enter Valid Zip Code Number\n";
		document.getElementById("errZip").innerHTML="Enter 6 digit ZipCode";
	}		

	if(error!=""){		
		return false;
	}

}