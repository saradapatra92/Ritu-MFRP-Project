
function doValidate() {

	var error="";

	var p1=frmRegister.password.value;
	var p2=frmRegister.retypePassword.value;

	var letters = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;  

	if(!(p1.match(letters)))
	{
		error+="Password too short\n";
		document.getElementById("errPassword").innerHTML="Password should contain atleast <br/> 1 special character,1 capital letter and 1 number";
	} 

	if(p1!=p2 ){	
		error+="Password Mismatch\n";
		document.getElementById("errRePassword").innerHTML="Password Mismatch";		
	}
	var firstn=frmRegister.firstName.value;

	if(!firstn.match(/^[A-Za-z]+$/)){
		error+="Enter Valid First Name\n";
		document.getElementById("errfirstName").innerHTML="Please use alphabets";
	}
	
	var lastn=frmRegister.lastName.value;
	if(!lastn.match(/^[A-Za-z]+$/)){
		error+="Enter Valid Last Name\n";
		document.getElementById("errlastName").innerHTML="Please use alphabets";
	}


	var usern=frmRegister.userName.value;

	var patt3 =/^[A-Za-z0-9]+$/i;
	if(!usern.match(patt3)){
		error+="Enter Valid User Name\n";
		document.getElementById("erruserName").innerHTML="User Name should be alphanumeric only";
	}

	var mob=frmRegister.mobile.value;

	var patt1 =/^\d{10}$/;
	if(!mob.match(patt1)){

		error+="Enter Valid Mobile Number\n";
		document.getElementById("errMobileNumber").innerHTML="Enter 10 digit Mobile Number";
	}


	var email=frmRegister.Emailid.value;
	
	if (!((/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/).test(email))){
		
	error+="You have entered an invalid email address!\n";
	document.getElementById("errEmail").innerHTML="Enter Valid Email";
	}
	
	var zip=frmRegister.zipCode.value;

	var patt2 =/^\d{6}$/;
	if(!zip.match(patt2)){

	error+="Enter Valid Zip Code Number\n";
	document.getElementById("errZip").innerHTML="Enter 6 digit ZipCode";
	}

	if(error!=""){

		return false;
	}


}